import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import LoginPage from "./Pages/LoginPage";
import ListPage from "./Pages/ListPage";
import ChatPage from "./Pages/ChatPage";
import ProfilePage from "./Pages/ProfilePage";
import Layout from "./Pages/Layout";
import Categorypage from "./Pages/Categorypage";
import VideoDlts from "./Pages/VideoDlts";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/auth" element={<LoginPage />} />
        <Route path="/dashboard" element={<Layout />}>
          <Route index element={<ListPage />} />
          <Route path="chat" element={<ChatPage />} />
          <Route path="profile" element={<ProfilePage />} />
          <Route path="category" element={<Categorypage />} />
          <Route
            path="videos"
            element={
              <VideoDlts
                catid={""}
                subcatid={""}
                load={function (value: React.SetStateAction<boolean>): void {
                  throw new Error("Function not implemented.");
                }}
              />
            }
          />
        </Route>
        <Route path="*" element={<Navigate to="/dashboard" />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
