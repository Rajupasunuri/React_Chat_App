import React, { useEffect, useState } from "react";
import Input from "../Components/Input";
import Button from "../Components/Button";
import { useDispatch, useSelector } from "react-redux";
import { AppDispatch, RootState } from "../Redux/store";
import AvatarGenerator from "../utils/avatarGenerator";
import { toastErr, toastWarn } from "../utils/toast";
import { BE_deleteAccount, BE_saveProfile } from "../Backend/Queries";
import { useNavigate } from "react-router";
import DatePicker from "react-datepicker";
import TimePicker from "react-time-picker";
import "react-time-picker/dist/TimePicker.css";
import "react-clock/dist/Clock.css";
import { TimePickerComponent } from "@syncfusion/ej2-react-calendars";
import dayjs from "dayjs";
import { DemoContainer, DemoItem } from "@mui/x-date-pickers/internals/demo";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
//import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { DesktopDatePicker } from "@mui/x-date-pickers/DesktopDatePicker";
import { MobileDatePicker } from "@mui/x-date-pickers/MobileDatePicker";
import { MobileTimePicker } from "@mui/x-date-pickers/MobileTimePicker";

import "react-datepicker/dist/react-datepicker.css";

function ProfilePage() {
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPass, setConfirmPass] = useState("");
  const [avatar, setAvatar] = useState("");
  const [birthDate, setBirthDate] = useState<Date | null>(null);
  const [mrgDate, setMrgDate] = useState<Date | null>(null);
  const [address, setAddress] = useState("");

  const [saveProfileLoading, setSaveProfileLoading] = useState(false);
  const [deleteAccLoading, setDeleteAccLoading] = useState(false);

  const currentUser = useSelector((state: RootState) => state.user.currentUser);
  const dispatch = useDispatch<AppDispatch>();
  const goTo = useNavigate();

  const [value, onChange] = useState<any>("10:00");

  useEffect(() => {
    setEmail(currentUser.email);
    setUsername(currentUser.username);
  }, [currentUser]);
  useEffect(() => {
    console.log(birthDate);
  }, [birthDate]);

  const handleAvatarGenerate = () => {
    setAvatar(AvatarGenerator());
  };

  const handleSaveProfile = async () => {
    // make sure email and username arent empty
    if (!email || !username) toastErr("Email or username can't be empty!");

    // if there's a password, make sure it's equal to confirm password
    let temp_password = password;
    if (temp_password && temp_password !== confirmPass) {
      toastErr("Passwords must match!");
      temp_password = "";
    }

    // only update email if it was changed
    let temp_email = email;
    if (temp_email === currentUser.email) temp_email = "";

    // only update username if it was changed
    let temp_username = username;
    if (temp_username === currentUser.username) temp_username = "";

    // only update avatar if it was changed
    let temp_avatar = avatar;
    if (temp_avatar === currentUser.img) temp_avatar = "";

    if (temp_email || temp_username || temp_password || temp_avatar) {
      // save profile
      await BE_saveProfile(
        dispatch,
        {
          email: temp_email,
          username: temp_username,
          password: temp_password,
          img: temp_avatar,
        },
        setSaveProfileLoading
      );
    } else toastWarn("Change details before saving!");
  };

  const handleDeleteAccount = async () => {
    if (
      window.confirm(
        `Are you sure to delete ${username}? This can't be reversed`
      )
    ) {
      await BE_deleteAccount(dispatch, goTo, setDeleteAccLoading);
    }
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <div className="bg-white flex flex-col gap-5 shadow-md max-w-2xl rounded-xl py-5 px-6 md:p-10 md:m-auto m-5 md:mt-10">
        <div className="relative self-center" onClick={handleAvatarGenerate}>
          <img
            src={avatar || currentUser.img}
            alt={currentUser.username}
            className="w-32 h-32 md:w-48 md:h-48 rounded-full p-[2px] ring-2 ring-gray-300 cursor-pointer hover:shadow-lg"
          />
          <span className="absolute top-7 md:top-7 left-28 md:left-40 w-5 h-5 border-2 border-gray-800 rounded-full bg-green-400"></span>
        </div>

        <p className="text-gray-400 text-sm text-center">
          Note: Click on image to temporary change it, when you like it, then
          save profile. You can leave password and username as they are if you
          don't want to change them
        </p>

        <div className="flex flex-col gap-2">
          <Input
            name="email"
            value={email}
            onChange={(e) => setEmail(e.target.value.trim())}
          />
          <Input
            name="username"
            value={username}
            onChange={(e) => setUsername(e.target.value.trim())}
          />
          <Input
            name="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <Input
            name="confirmPassword"
            type="password"
            value={confirmPass}
            onChange={(e) => setConfirmPass(e.target.value)}
          />

          <Input
            name="address"
            type="text"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
          />

          <DemoItem label="BirthDay">
            <DatePicker
              selected={birthDate}
              onChange={(date: any) => setBirthDate(date)}
              className="flex-1 w-full border-2 p-1 pl-3 rounded-3xl border-gray-200"
              dateFormat="dd/MM/yyyy"
              placeholderText="Pick the Date"
            />
          </DemoItem>

          <DemoItem label="Marriage Day">
            <DatePicker
              selected={mrgDate}
              onChange={(date: any) => setMrgDate(date)}
              className="flex-1 w-full border-2 p-1 pl-3 rounded-3xl border-gray-200"
              dateFormat="dd/MM/yyyy"
              placeholderText="Pick the Date"
            />
          </DemoItem>

          <DemoItem label="My Day Starts At">
            <MobileTimePicker
              defaultValue={dayjs("2022-04-17T15:30")}
              slotProps={{
                textField: { size: "small" },
              }}
            />
          </DemoItem>

          <Button
            text="Update Profile"
            onClick={handleSaveProfile}
            loading={saveProfileLoading}
          />
          <Button
            text="Delete Account"
            onClick={handleDeleteAccount}
            secondary
            loading={deleteAccLoading}
          />
        </div>
      </div>
    </LocalizationProvider>
  );
}

export default ProfilePage;
