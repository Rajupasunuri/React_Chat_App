export default function Truncate(text: string) {
  return text.substring(0, 30) + "...";
}
